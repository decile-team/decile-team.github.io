window.onGatsbyPreRouteUpdate = function() {
window.removeMainNavigationHandlers();
};