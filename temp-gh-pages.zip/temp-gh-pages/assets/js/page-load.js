window.onGatsbyRouteUpdate = function() {
window.addMainNavigationHandlers();
};